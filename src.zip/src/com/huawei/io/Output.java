package com.huawei.io;

import java.util.List;

public class Output {

    public static void Print (List<String> list){

    }


}
