package com.huawei.common;

public class WorkStation{
    public double x;
    public double y;
    //工作台类型
    public int type;
    //工作台id
    public int id;
    //原材料格状态
    public int state;
    //产品格状态
    public boolean production;
    //剩余生产时间
    public int time;

}